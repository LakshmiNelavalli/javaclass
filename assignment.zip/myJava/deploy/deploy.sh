# /bin/bash

cp ../bin/* ../../
echo "deployment done!"
